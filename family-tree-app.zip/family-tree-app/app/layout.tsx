import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'My Family Tree', description: 'Your private interactive family history' };
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) { return <html lang="en"><body>{children}</body></html>; }
