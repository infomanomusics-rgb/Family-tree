# Kinfolk — My Family Tree

A modern responsive Next.js family tree app. Add/edit/delete members, upload compressed portraits, connect parents and spouses, explore a zoomable family diagram, search members, and import/export backups.

## Local setup

Requires Node.js 20 or newer.

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Deploy for free on Vercel

1. Create a GitHub repository and upload the contents of this folder (keep `app` at the repository root).
2. At https://vercel.com/new select **Import Git Repository** and choose your repo.
3. Framework preset should detect **Next.js**. Leave build settings at defaults.
4. Click **Deploy** and open your generated `vercel.app` URL.
5. On mobile, use browser Share > Add to Home Screen (iPhone) or browser menu > Add to Home screen (Android).

## Important data notes

- Changes are stored in localStorage **on that device/browser only**. No login, cross-device sync, or cloud backup.
- Use **Backup** regularly to download JSON and **Import** to restore it.
- Clearing site data or using a different browser can lose access to locally saved information.
- Family data is personal. Do not publish JSON backups to public GitHub repositories.
- Sample people are fictitious and can be deleted.
- The diagram uses a generation-based layout; complicated blended family connections may overlap. For large genealogy trees, a dedicated graph layout library is recommended.
